--1) Criar esquema STESTE no database SENAC
CREATE SCHEMA STESTE
GO

--2) Criar uma tabela XPTO (X int, Y int) no esquema STESTE; 
CREATE TABLE STESTE.XPTO (X int, Y int)
go

--3) Criar uma VIEW VTESTE no esquema STESTE; 
CREATE VIEW  STESTE.VTESTE 
as
SELECT * FROM Medicos 
go

--4) criar um procedimento armazenado SPTESTE no esquema STESTE
CREATE PROCEDURE STESTE.SPTESTE 
AS 
SELECT 'DB ROCKS'
go
--AECV
--1
CREATE PROCEDURE teste11 AS
SELECT 'BANCO DE DADOS ROCKSSSSS!!!'

--2 
CREATE PROCEDURE PmedicosRJ
as
select nome, especialidade, cidade
from medicos
where cidade = 'RJ'

exec PmedicosRJ

--3
CREATE PROCEDURE pCPF (@P1 as VARCHAR(11))
AS
SELECT *
FROM pacientes
WHERE cpf=@P1

exec pCPF 12345678911

--4
DROP PROCEDURE PmedIdade
CREATE PROCEDURE PmedIdade (@P1 as int)
as
select nome, especialidade
from medicos
Where idade=@P1

exec PmedIdade 56

--5
DROP PROCEDURE Pamb
CREATE PROCEDURE Pamb (@P1 as int)
as
select m.nome, m.codm, a.andar, m.nroa
from medicos m join Ambulatorio a on m.nroa=a.nroa
Where codm=@P1

exec Pamb 45

--6 
CREATE FUNCTION M53 (@P1 DEC(5,2), @P2 DEC(5,2), @P3 DEC(5,2), 
                    @P4  DEC(5,2), @P5 DEC(5,2))
RETURNS DEC(5,2)
AS
BEGIN
	DECLARE @MEDIA DEC(5,2)
	SET @MEDIA = (@P1 + @P2+ @P3+ @P4+ @P5) / 5
	RETURN @MEDIA
END

SELECT dbo.M53(1,2,3,8,5) as media

--7 
CREATE FUNCTION RAIZ2GRAU (@A DEC(5,2), @B DEC(5,2), @C DEC(5,2))
RETURNS @TBL TABLE (RAIZ1 DEC(5,2), RAIZ2 DEC(5,2))
AS
BEGIN
    DECLARE @R11 DEC(5,2)
	DECLARE @R22 DEC(5,2)
	SET @R11 = (-@B+SQRT(@B*@B-4*@A*@C))/ (2*@A)
	SET @R22 = (-@B-SQRT(@B*@B-4*@A*@C))/ (2*@A)
	INSERT INTO @TBL VALUES(@R11, @R22)
	RETURN
END


SELECT * from dbo.RAIZ2GRAU(3,-7,4)
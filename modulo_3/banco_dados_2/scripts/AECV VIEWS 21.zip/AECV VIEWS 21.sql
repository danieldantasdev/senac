--1 Construa uma vis�o chamada �EspecialistaRJ� com m�dicos somente com os atributos codm, nome e especialidade daqueles m�dicos que moram no �Rio de Janeiro� 
CREATE VIEW EspecialistaRJ AS
SELECT codm, nome, especialidade
FROM medicos
WHERE cidade='Rio de Janeiro'

go
select * from EspecialistaRJ
go
--2 Construa uma vis�o chamada �GrupodeRisco� da tabela pacientes, com os campos nome, doen�a, cidade que tem como doen�as �Pneumonia�, �Hipertens�o� ou �Gripe�
CREATE VIEW GrupodeRisco AS
SELECT nome, doen�a, cidade FROM Pacientes
WHere doen�a in ('Pneumonia', 'Hipertens�o', 'Gripe')
go
SELECT * FROM GrupodeRisco
go
--3 Construa uma vis�o chamada �CapacidadesMedicas� com os campos especialidade, e sua quantidade 
CREATE VIEW CapacidadesMedicas AS
SELECT especialidade, Count(*) as Quantidade FROM medicos
GROUP by especialidade
go
SELECT * FROM CapacidadesMedicas

go
--4 Construa uma vis�o chamada �consultasDez20� com nome do medico, nome do paciente, data e hora das consultas dos m�s de setembro de 2020
CREATE VIEW consultasSet20 as
SELECT m.nome as Medicos, p.nome As pacientes, c.data, c.hora
FROM medicos m join consultas c on c.codm=m.codm join pacientes p on c.codp=p.codp
WHERE c.data >= '2020-09-01' and c.data <='2020-09-30'
go
select * from consultasSet20 
go

--5 Construa uma vis�o chamada �consultasRisco20� com a quantidade de consultas para cada doen�a do grupo de risco �Pneumonia�, �Hipertens�o� ou �Gripe� em 2020
CREATE VIEW consultasRisco20 AS
SELECT doen�a, count(*) as quantidade
FROM pacientes p join consultas c on p.codp=c.codp
WHere doen�a in ('Pneumonia', 'Hipertens�o', 'Gripe') AND
      c.data >= '2020-01-01' and c.data <='2020-12-31'
Group by doen�a
go
DROP VIEW consultasRisco20

SELECT * FROM consultasRisco20
USE HOSPITAL
select * from consultas

--1 
--2 Execute a consulta SELECT * FROM Consultas where data = '30/09/2015' � Apresente o plano de execu��o. 
SELECT * FROM Consultas where data = '30/09/2015'

--3 Crie um �ndice n�o clusterizado no campo �DATA� da tabela Consultas e refa�a a consulta anterior �e  apresente o plano de execu��o. O que aconteceu?
CREATE NONCLUSTERED INDEX IDX_Data on CONSULTAS(DATA)

--4 Execute a consulta SELECT * FROM Consultas where data = '30/09/2015� and codp=1020  � Apresente o plano de execu��o. 
SELECT * FROM Consultas where data = '30/09/2015' and codp=1020

--5 Crie um �ndice n�o clusterizado no campo �codp� da tabela Consultas e refa�a a consulta anterior � Apresente o plano de execu��o. O que mudou?
CREATE NONCLUSTERED INDEX IDX_Codp on CONSULTAS(Codp)

--6 Execute a consulta SELECT nome, Data, hora FROM medicos m join consultas c on m.codm=c.codm � Apresente o plano de execu��o.
SELECT nome, Data, hora FROM medicos m join consultas c on m.codm=c.codm

--7 Execute a consulta SELECT nome, Data, hora FROM medicos m join consultas c on m.codm=c.codm WHERE m.codm=90 � Apresente o plano de execu��o. 
SELECT nome, Data, hora FROM medicos m join consultas c on m.codm=c.codm WHERE m.codm=90

--8 Avalie agora a tabela �Pacientes� e liste os �ndices encontrados, especificando seu tipo e origem
SELECT* FROM Pacientes WHERE Codp=1020 -- chave primaria gera indice clusterizado
SELECT * FROM PACIENTES WHERE CPF='05234567890' -- Rerstri��o UNIQUE gera indice Nao Clsuterizado
SELECT * FROM PACIENTES WHERE Sexo='M'

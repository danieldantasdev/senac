Set Transaction Isolation Level Read Uncommitted
Set Transaction Isolation Level Read committed
Set Transaction Isolation Level REPEATABLE READ
Set Transaction Isolation Level SERIALIZABLE
use BD2
go
-- LEITURA SUJA
CREATE PROCEDURE T1a AS
Begin Transaction Tx1a
	Update medicos Set idade = 46 Where codm =99
	waitfor delay '00:00:20'
Rollback
go
exec T1a

Select codm, nome, idade, especialidade From Medicos
Where codm = 99
go
-- LOST UPDATE
Create Procedure T2a (@NOME varchar(40)) as
Begin Transaction Tx2a
	UPDATE MEDICOS SET NOME=@NOME WHERE CODM=50
	waitfor delay '00:00:05'
	Select codm, nome, idade From Medicos Where codm = 50
Commit
go
t2a 'DANTAS'

--Non-Repeatable Read 
Begin Transaction T3a
	Select nome, idade From Medicos Where codm = 99
	waitfor delay '00:00:20'
	Select nome, idade From Medicos Where codm = 99
Commit
go

--Phanton Reads 
BEGIN TRAN T4a;  
	SELECT codm, nome FROM medicos WHERE codm < 50
	waitfor delay '00:00:15'
	SELECT codm, nome FROM medicos WHERE codm < 50
Commit

delete from medicos where codm<41
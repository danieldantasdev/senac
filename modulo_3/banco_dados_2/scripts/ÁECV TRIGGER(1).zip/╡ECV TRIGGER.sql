--CRIANDO TABELA DE EVENTOS
CREATE TABLE CREATE TABLE Evento(
EventoId int IDENTITY(1,1) PRIMARY KEY, 
Data Datetime NOT NULL, 
Medico int, 
Descricao varchar(40) )

--------------------------------------------------------------------

--1 Registrar adição de um novo médico, registrando no log ‘Medico Adicionado’)
CREATE TRIGGER LOGA_NOVO_MED
ON Medicos
FOR INSERT
AS
BEGIN
	DECLARE @MEDICO int
	SELECT @Medico = Codm FROM INSERTED
	INSERT INTO EVENTO values (GETDATE(), @MEDICO, NULL,  'MEDICO ADICIONADO')
END

-- testando a trigger criada
go
SELECT * FROM evento
go
INSERT INTO MEDICOS values (31, '12345676543', 'Lissa', 25, 'Niteroi', 'Pediatria', NULL)
go 

--2 Registrar alteração de cadastro de um médico, registrando no log ‘Medico Alterado’) 
CREATE TRIGGER LOGA_ALTERA_MED
ON Medicos
FOR UPDATE
AS
BEGIN
	DECLARE @MEDICO int
	SELECT @Medico = Codm FROM INSERTED
	INSERT INTO EVENTO values (GETDATE(), @MEDICO, NULL, 'MEDICO ALTERADO')
END
go

-- testando a trigger criada
Update medicos set idade =21 where codm=31
SELECT * FROM evento
go

--3 Registrar deleção de um médico, registrando no log ‘Medico apagado’) 
CREATE TRIGGER LOGA_APAGA_MED
ON Medicos
FOR DELETE
AS
BEGIN
	DECLARE @MEDICO int
	SELECT @Medico = Codm FROM deleted
	INSERT INTO EVENTO values (GETDATE(), @MEDICO, NULL, 'MEDICO APAGADO')
END
go

-- testando a trigger criada
DELETE FROM medicos where codm=31
select * from evento
go
--4 Ao incluir um novo médico verificar se o ambulatório sugerido já está em uso por mais de 3 médicos. Caso positivo efetivar o adastro com valor NULL no campo de ambulatório, registrando no log como ‘DEFINIR NOVO AMBULATORIO)
go
CREATE TRIGGER LOGA_MEDICO_3
ON MEDICOS
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @Medico INT, @CPF char(11), @nome varchar(40), @idade int, @cidade varchar(15), @especialidade varchar(30), @nroa int

    SELECT @Medico = Codm, @CPF=CPF, @nome=nome, @idade=idade, @cidade=cidade, @especialidade=especialidade, @nroa=nroa FROM INSERTED

    IF (SELECT COUNT(*) FROM medicos  WHERE nroa= @nroa) <3
    BEGIN
   	 INSERT INTO Medicos VALUES (@Medico, @CPF, @nome, @idade, @cidade, @especialidade, @nroa)
   	 INSERT INTO Evento VALUES (GETDATE(), @medico, null,  'INSERIDO')
    END
    ELSE
 	 INSERT INTO Evento VALUES (GETDATE(), @medico, null,  'SEM AMBULATORIO')
 END
 go

 -- testando a trigger criada
 INSERT into Medicos values (31, '12345543011', 'Raquel', 48, 'Teresópolis', 'Pediatria', 101)
 INSERT into Medicos values (31, '12345543011', 'Raquel', 48, 'Teresópolis', 'Pediatria', 503)
 select * from evento
 select nroa, count(*) from Medicos
 group by nroa
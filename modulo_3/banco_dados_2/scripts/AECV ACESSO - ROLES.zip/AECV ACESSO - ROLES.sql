--1) Criar uma Role de servidor chamada RSTESTE
CREATE SERVER ROLE RSTESTE
GO

--2) Tornar o login �alunolg� membro da Role RSTESTE
ALTER SERVER ROLE RSTESTE ADD MEMBER alunolg

--3) Apagar Role de servidor chamada RSTESTE
ALTER SERVER ROLE RSTESTE DROP MEMBER alunolg -- esvaziar a ROLE
DROP SERVER ROLE RSTESTE
go

--4) Criar uma Role de DATABASE chamada RTESTE no database �SENAC�
CREATE ROLE RTESTE
GO

--5) Tornar o usu�rio �aluno1� membro da Role a RTESTE
ALTER ROLE RTESTE ADD MEMBER aluno1

--6) Retirar o usu�rio �aluno1� da Role a RTESTE
ALTER ROLE RTESTE DROP MEMBER aluno1

--7)Tornar o usu�rio �aluno1� apto a criar objetos no Database
Alter role db_ddladmin add member aluno1

--8)Tornar o usu�rio �aluno1� owner do Database
Alter role db_owner add member aluno1

--9)Tornar o usu�rio �aluno1� apto tirar backup no Database
Alter role db_backupoperator add member aluno1


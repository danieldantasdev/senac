--1) Criar o login �alunolg� (senha 12345) no servidor (desconsidere a politica de senhas do servidor)
CREATE LOGIN alunolg WITH PASSWORD = '12345', check_POLICY=OFF

--2) Entre com o login �alunolg� e tente acessar o database �Senac�. O que aconteceu?
-->> NAO PERMITIDO - porque n�o existe usu�rio criado

--3) Apague  o login �alunolg� 
DROP LOGIN alunolg

--4) Recriar o login �alunolg� (senha 12345) no servidor (desconsidere a politica de senhas do servidor) e o associe ao database SENAC
CREATE LOGIN alunolg WITH PASSWORD = '12345', check_POLICY=OFF

--5) Criar o usu�rio �aluno1� no database �SENAC�, associando o mesmo ao login �alunolg�
use SENAC
CREATE USER aluno1 FOR LOGIN alunolg
SELECT * FROM medicos

--6) Entre com o login �alunolg1� e tente o acesso no Database SENAC. O que aconteceu?
-->> Temos acesso a DB SENAC, porem nao acessamos nenhum dos seus objetos


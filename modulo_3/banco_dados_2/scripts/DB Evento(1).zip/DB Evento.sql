CREATE TABLE CREATE TABLE Evento(
EventoId int IDENTITY(1,1) PRIMARY KEY, 
Data Datetime NOT NULL, 
Medico int, 
Descricao varchar(40) )
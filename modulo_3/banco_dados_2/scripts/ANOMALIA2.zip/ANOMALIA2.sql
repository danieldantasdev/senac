Set Transaction Isolation Level Read Uncommitted
Set Transaction Isolation Level Read committed
Set Transaction Isolation Level REPEATABLE READ
Set Transaction Isolation Level SERIALIZABLE
use BD2
go
-- LEITURA SUJA
CREATE PROCEDURE T1b AS
Begin Transaction Tx1b
Select codm, nome, idade, especialidade From Medicos
Where codm = 99
COMMIT
go

exec T1b
go
-- LOST UPDATE
CREATE PROCEDURE t2b (@NOME varchar(40)) as
Begin Transaction T2b
	waitfor delay '00:00:10'
	UPDATE MEDICOS SET NOME=@NOME WHERE CODM=50
	Select codm, nome, idade From Medicos Where codm = 50
Commit
go
t2b 'ROBERTO'
go

--Non-Repeatable Read 
Begin Transaction T3b
	Update medicos Set idade = 80 Where codm =99
Commit
go

--Phanton Reads 
BEGIN TRAN T4b; 
	INSERT INTO Medicos VALUES (41,'99999567890','Lucas','21', 'RJ', 'Infectologia', 201);
Commit
go
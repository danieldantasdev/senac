import React, { useState, useEffect } from "react";
import { SafeAreaView, View, StyleSheet } from "react-native";
import { TextInput } from "react-native-paper";
import { Dialog, Portal, Provider, Button, Text } from 'react-native-paper';
import DropDownPicker from 'react-native-dropdown-picker';


const Formulario: React.FC = () => {
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(null);
    const [descricao, setDescricao] = useState('');
    const [status, setStatus] = useState('');
    const [data, setData] = useState<string | undefined>();
    const [visible, setVisible] = useState(true);
    
    const [nivel, setNivel] = useState('');
    const [items, setItems] = useState([
      {label: 'Foundation', value: '1'},
      {label: 'Associate', value: '2'},
      {label: 'Expert', value: '3'}
    ]);

    const fetchData = async () => {
        try{
        const resp = await fetch('http://academico3.rj.senac.br:8080/api/Badge', {
        method: 'POST',
        body: JSON.stringify({
        descricao: {descricao},
        imagem: "aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQVRjQUFBQ2lDQU1BQUFBVElIcEVBQUFCRjFCTVZFWC8vLy80eUR2NHp6NzR4RG40elQzNHhqcjQwRDc0eXp6NHlUdjR3amo0d0RmNDBqLzR2amY0MUVENHZEWTVRazcveURZMFAwNCtSVTMvMGpvdE8wNzl4VGNqTlU3NHh5My8xVHJ4dkRnd1BVNDVRazM5emp2OTZibi96RFg0MEN3b09FNGFNRS8vL1BhWmdrVkxUa3hwWTBvQUowK0RkVWorK3ZCalhrb1BMVTlXVkV2Kzh0bis5ZUw0dWlUNjJVbjczbWIrN3JYOTZhSCs4Y3JOcmtIWHRVQzlvRU9maWtXMG1VT01lMGQ0YkVtb2tFVHF3RHhFU1UwQUlsRElvMERTcHozN3lsdjd4a3YrNWJUODVvdis4THo1MmxYOTdhLzg0b0g4NEhQOTU1ajV6Q1JhV1V2Q3AwUC8zRHJodkQvODM0djcxVnQrYjBqODFXLzgzNXlLZFViNHZ4bmVzRHVkZ2tTN2wwRDcxWHY5MnBEODNxVkhObXYxQUFBS21rbEVRVlI0bk8yYy9VT2F6aC9BS3pWelpvREFKVW9DNFVPQ1VrMU5CVTJydGJYWlBtNjJhUS83Ly8rTzd3SFcxN1Y4NExEb2xOY1ByVXZ2QnErOTc5N3ZPMmxyYXo0K1BqNm9sSTQvSHBlOHZnamNLSDQ2RkV3T1B4Vzl2aFI4T1BoNEtNUkdKSVRETC90ZVh4QVdGSytFSjJzV2duRGxCOTBzeWtkQ0l2WVB3bEhaNnd0NzExd2VDdjlLczgxOXZ2VDY0dDR0eHhPdCtlWW04MldxTmN2YzRiSFhGL251T0k3TnNtYVppL2t4Tjg3a2RlM2ZtUE16eENPWG4rZTFacGs3OHFzU2s3SWphN0ZZTkNaY0hYaDkwWjVUT2hLaXpoRStlbjNkM25Md1NZZ2hhSU1oZDdqS0NlTGpTM3VET1dlcjhIbFZsN241U28vSnJPWXlCOU5CMUpVMk0rWldicGtyZlhWdHpSSzNZblh3TnlHNmlaSVBYc2lzSzFUTlhjWlFhbytKNWxaa21Tc2lWV3hUemEzQU1yZi9hZEhXVEhGTHY4eGRDb25GYXpQTkxYVTFaMjZxTmw4SHVNd3Q3WWVHMzRSWGttYXpwTXRjT2ZacXdXWVRGUTZYYjdMdVg3MXVzTmtJUDVic3M5WnlMUEc2d1dZVHBXUExkQng4OEZWWTBQWmdKcHZkcTZVSnViMEUvUWF4OWtnaXVpUWg5eVlyMnpqQ2xkZTN2QUNLMGJjTU5oczZpbjFpL2RoOWMyc21tTmR5QjBkdTUrZ0dxcmdqak5ORE1ZRjgzeU1TR2NTT0c1c3hiT2ZxcGJEaGxrU212b25hVjhBMHIzN3B1dGEya1dqcENlVE8zUzllSzBEaGVBSGFOcHRBUmZlMjBjWHcrYVdTKzBrS3c2MEdybDE0MitqaWQ3YjBnMTZBdHFySXlHNjgwZmhWd05FRmFQc3VFa3JQMVJCUnJ6VTRwZVIrZGFNYmdBQTFlZ001b1VLNnVCVWplMjY5MGIyTVNJQjhndDQ4cWJnWVpjOXJFUTc1eHJ2VVZoRXBRbW9rNkhwU0Q2SVB3Ly93V29SRGJ0eDVveXNTUVlINmY5Vld6a2k0OEJZODhscUVRNkl1YmhiU0JBUkZWZjlyU05KM04va1V2OFRRZGVVdG9TY3BvcG5RQVhDcExTamd0YjB2ZGNOQkY4QndFM3NKQThEcXpjMHd3V0FZczhxMzJIVjF1eFZBcVRTdFVxRHFUbHN3aUZraGNybnI2bTZyZ01yUWRJWVNUM2lYM25ieEtrU08zWGtMVXBRWXBMTVVGWGVwTGJpTDE1bklMM2R4UXNzaXFOQ0dTSWd5N2M0Ymo5ZUIrUSszODR0aW9MRTRSWWdiTHIzaFZmaGVoZDNCVjZVa3pWY0JJZlZjanZUVmF4V08rTXE3dkYzNjVQUTdUOWNZWUEwRTR5YUlPQkJlRzRhZjZPVWJ6OU0welFmcGt4YlAxNVdhT2VINThQZDZoVWNhTXZ6VGF4V09RUGJHaDAva2JLWUZkZkU5bUZHek1DM3dkRjNKQWFtQU9LTFhLaHlCdkpwWEdRRHlWVHJCVzJIWFNDVDRacVhPQjZ2WkpLaWo1SnJ3aHRjcW5MQy9nYmdhOFhXSm9GUTkzNUJyTmJtUnoyY3pUQzRGcHlpZmlDZXpOTXFJbXpodFVQZVJidEVTSjFNQWlDS3drYVI0dnNLYnFZRlBKYk5JdVliRzZiY2JEcnFvM3NKOHVIb2k1L082cnVkbG85M2phY3NXTFRQQVFQSzJ1eUxld3VHbW51RVROblM0V3QrQ3VtaERBanBhYWRQRnlWdHBGMTBiMzVCU0JiakF5VEpjM2VDRVpTbzhMZWNZQTNIcTcrSjBrRlIwNFEzR215U0J4d1dPS2NpVmNLWmxoRkVMNlYyY0RwS0t1MXZvaE9FR3k0QkxYS05XcnpSaENjeUhtM0NSUXgwTksyOWxOOTYydG1yWFRYTnhnNFNicGpGa2FhWTNuSjVLY3VVTjdxNlM4VUplcnNuNWEwTFNtMjZzcllvM3VFMkEweklwSnBOSmhtSE1yMG84YkwvZ2U1dHNyV2YwVmJYQnI5ZjdLaUZLUUd4bGExVlRXSml2dEJIRERxdUQ4ajJrZk1yWEpOQzNNZ0hjbS9KYjYrdGJ2UGs5YkcyMUN3VjZDeTJmNHVVTktkejZJa0VWNUhxbDExeTM3am00M3V4VlRtcjlscEpUbTczcUtzUWIwajNDeWczWVcxTW1tWXJIVTVRb1NZcWlTTmUxSG04b3ZyZUo4TTIya2RjTGFxWmxrbEVMZXNQY28yNjE4eUJYUjhzTXV4ZGV5M0FBcWpkVEhTMzNmOE5kVnExbVFHQXRvaGRTdVJ5Vjd5RW0xRlh4Qm9GQjE5Q3ZXM0NhTWxROFU4alhUbnBoMURKa2xieFpWUnh0cDFJN283b1lDek52Nis4RjN4c2F2amMwZkc5bytON1E4TDJoZ2RsK0lmUmV3TXBiMlk4M0pIeHZhTHduYjNpZDkzcXQ2d25mR3hwWWVTdWk1OU4wZW9ISkZJS1h0d0h5ZmVyWnhUa3p3ZXB6NXhKeXZLMm5tRVZhV3hsdm9UaGxmbDFmLy91bno5c092T0gwWE0yQk8yL2swREE2WkdqWWFVSmp3MDRvUGF3YmJWUnZPRDNINWM0YldjaEppcExuNjZmOWRDZ2dnYlNjVXlSRlhRRnYrK3NCUktDM0FGbXZrNkZzYmhnaWtvRlFYYXFsTzNLSWxKVTdGbVhBWFp5ZTcxMXo1UzFnenN1KzFFN0wwaDEvTFRVRDZlYWRJUU9aUkJsdzNXc1ZqamhIa3hheXZSVnlWRUVGYmJLcFpEbEZUNU1OQlZ3WFJEUnY1MTZyY01SNXdQbEtGT0R1T3VrQWswclhGVGxORzFJN2xDNHdEYWxORHBWc21oNUtNb213dkdIbTdTZUN0MUQ3TkZYWFFUOWRsL3JOZGhMQUROb0dUSXNNREJWMU9Nd3dhTjd3K2oyakc1UlpDdGQrUllwem9WQWhsNVAwVTdQeW9ISTFNZ1RuYWU2MGY5cEFtcWMzWHF0d3hBK2szRWNPMngzUytyTVRDSERXajZ5dkpOZmhTQTVseEFCNzc3VUtSL3hDaWczelBoSDdUUnp2bDljcUhIR002bTNSa0grOFZ1R0l2WGZqRGFkamN2TWd5V3RoSXdZNEhZZXNyWlVHa2ZmQkFLZmpFTGhCZlRmZXNOcWVycTJGdkJZMkl1UzFDSWVjZVMxc3hKblhJaHp5d0hwdHpJSjk4RnFFUXk3bUxHRFp5Ti9Oc2U4amdjaUVWd0tSWjkwbUQ0OVhHV0lXSW5QRkF5bm55YkdXMmg0TFV3NXdZNEhUem95L3NkRVlhMDBCczNRS21XK2Vjc3lZSExZampja2haVEFtaDFTbE1hZWNLSTQ1blVMQWF3Mk91Wjh0amlYVHR3elRTSlBzcUhWTmdiYmRZa2t5SUJJZ1FvNWE2VGFnMVBSVFMyWVllZFJ0K3QrQTIvSTJUK1hML2M2MkdJSkl4Z3UvaHpEVzhvVlVraUNZakM3RCs3M3JxN0JCSkZYZGdIWmtQUVBmU0JIWGZSaHpROWd0YVhiTHdtNHp3Rythd3N3d1N4eG5Xak5oS0E1NkEwbXJRWUVzOUdZb2xOMVNicUUzSGRpdHBOUmhJMXo4c1Z0ODFsd2Q0UFNNNmhNenhVVXlsZzZxWmQ0L083UjFNTG81L1VnRFdDMWdtRXNjcTl1dmlSM3pOVzdVTFROVEcxNW5JVStVQngrbUVvbUlsZzJPTlZ0c3gyeFJLaGt4VytTdHFTb3BrOVk3NGNwbnZySE5qblVEa2NqMDRRZTQxU0JQRk5ucDNqanpmemNtd05CcXNXMFJMbUZFM0RiRi9rN0NWakp2ajBEQ0VLTUk4YzV1amJweDA3MnhlSjJFL01YQm1UYk5Xd2VJR1JVQU80ellXeEVVQ0dha2d5MHdJQXNZMVRZVkFReVZCYUpzdjdFTmdHcDJtK1p0Y0lQWmh2NFp2NmJNVmZhT3VpUEp1L2l0clVOWE8yVGtWdXJZcGlpZFMzTjl4bll6Vkc0alpPYzZhNy9SU0puZFVzYVVhTVoxYWZzL3hjQ1UyNHZBMTJDR3RCc2NhN1llWjUrNTZFWFkwVXRXaTMxcTJkMm0vSU1FTUo2amoremZ6MGdQQzJlQTEyZFlFeWxQVHcrTGhzWHB5ZFNwdkdYSWFUYzRQYmcxaXozMmJXSk93KzdnYUFadkUzS0RlN3lyajVjb0I2YlZjb3RBQ3l6Tnl2WVhENjhiY2dQOERvM21wSFNtYmIrU3RHM3RETU16bzduWjAxNW5zbXJha3VXRDUrdy9EQllmY3R2YXcvTGxnK2NVRnoxWjRSUmRnbTNWSE95eEM1eXMyMHRYc2szaFFkdGVFQiswcGMyaUwxRzYwWFlXWUcxSHUxbm1MUG9TNVhQM01hZWRyOGJDOWpjWHJEdHoyZ2NzUDY1eUQ2eEowTTFwMnEvbHJ6MG1jWENQS0c1SHUxK200eUxub0NXSTFVc0gvd0xyWUdmbWRsYWx6cDBGVEszem05dlJ6cGZ6dEFpRnZYbk43V2pjNnV3TzV1SGl3eHptZGxhMjlKakN4ZllNYzc2MUNaam1KcU9kKzlZbXNjZE5NdWRuZyttVXo3UVgxR2xudnJWWkZPK2ZtZE8wZTc5ZW00ZURQOXRQNmpUdC9NL3E3a01kVTN5QTZpRG5EMzZvT2FSNDhlZkMzNFg2K1BqNCtQZ3NNLzhEbWxtZTREb08wZHNBQUFBQVNVVk9SSzVDWUlJPQ==",
        status: {status},
        badgeNivelId: {nivel},
        }),
        headers: {
        'Accept': 'application/json',
        'Content-type': 'application/json; charset=UTF-8',
        },
        })
        const r = await resp.json();
        console.log(r);
        setData(r.mensagem);
        }catch(err){
        console.log(err);
        }
        };
        
        useEffect(() => {
        fetchData();
        }, []);    
      
return(
<View>
<TextInput
     style={styles.input}
     placeholder="Descrição"
     keyboardType="ascii-capable"
     onChangeText={setDescricao}
     value={descricao}
   />
<TextInput
     style={styles.input}
     placeholder="Nível do Badge"
     keyboardType="numeric"
     onChangeText={setNivel}
     value={nivel}
   />
<TextInput
     style={styles.input}
     placeholder="Status"
     keyboardType="numeric"
     onChangeText={setStatus}
     value={status}
   />
      <DropDownPicker
        open={open}
        value={value}
        items={items}
        setOpen={setOpen}
        setValue={setValue}
        setItems={setItems}

        theme="LIGHT"
        multiple={false}
        autoScroll={true}
        mode="BADGE"
        badgeDotColors={["#e76f51", "#00b4d8", "#e9c46a", "#e76f51", "#8ac926", "#00b4d8", "#e9c46a"]}
      />
    <Button onPress={fetchData}>Salvar</Button>  
</View>
);
};

const styles = StyleSheet.create({
input: {
height: 40,
margin: 12,
borderWidth: 1,
padding: 10,
},
container: {
flex: 1,
backgroundColor: '#F7F7F7',
marginTop:60
},
});

const Post: React.FC = ({ navigation }: any) => {



return (
<SafeAreaView style={styles.container}>
<Provider>
<View>
<Formulario/>

</View>
</Provider>
</SafeAreaView>
);
};

export default Post;
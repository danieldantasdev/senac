import React from "react";
import { View, Text } from "react-native";

interface DeleteProps {
navigation: any;
}

const Delete: React.FC<DeleteProps> = ({ navigation }) => {
return (
<View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
<Text>Delete</Text>
</View>
);
}

export default Delete;
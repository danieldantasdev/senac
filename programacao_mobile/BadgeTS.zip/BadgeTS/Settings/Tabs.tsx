import React from "react";
import {NavigationContainer} from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import List from '../Badges/List';
import Post from '../Badges/PostForm';
import Badge from '../Badges/Badge';
import Delete from '../Badges/Delete';
import { Ionicons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

interface TabsProps {
navigation: any;
}

const Tabs: React.FC<TabsProps> = ({ navigation }) => {
return (
<NavigationContainer>
<Tab.Navigator initialRouteName="Badge" screenOptions={({ route }) => ({
tabBarIcon: ({ focused, color, size }) => {
if (route.name === 'Badge') {
return (
<Ionicons
             name='shield-sharp'
             size={size}
             color={color}
           />
);
} else if (route.name === 'List') {
return (
<Ionicons
             name='list'
             size={size}
             color={color}
           />
);
}else if(route.name === 'Post'){
return (
<Ionicons
             name='save'
             size={size}
             color={color}
           />
);
}else if(route.name === 'Delete'){
return (
<Ionicons
             name='trash'
             size={size}
             color={color}
           />
);
}
},
tabBarInactiveTintColor: 'gray',
tabBarActiveTintColor: 'tomato',
})}>
<Tab.Screen name="Badge" component={Badge} />
<Tab.Screen name="List" component={List} />
<Tab.Screen name="Post" component={Post} />
<Tab.Screen name="Delete" component={Delete} />
</Tab.Navigator>
</NavigationContainer>

);
}

export default Tabs;
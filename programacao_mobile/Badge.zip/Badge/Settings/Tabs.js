import React, { useState, useEffect } from "react";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import List from '../Badges/List.js';
import Post from '../Badges/Post.js';
import Badge from '../Badges/Badge.js';
import Delete from '../Badges/Delete.js';
import { Ionicons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

export default function  Tabs({ navigation }) {
  return (
    <Tab.Navigator initialRouteName="Badge" screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          if (route.name === 'Badge') {
            return (
              <Ionicons
                name='shield-sharp'
                size={size}
                color={color}
              />
            );
          } else if (route.name === 'List') {
            return (
              <Ionicons
                name='list'
                size={size}
                color={color}
              />
            );
          }else if(route.name === 'Post'){
            return (
              <Ionicons
                name='save'
                size={size}
                color={color}
              />
            );
          }else if(route.name === 'Delete'){
            return (
              <Ionicons
                name='trash'
                size={size}
                color={color}
              />
            );
          }
        },
        tabBarInactiveTintColor: 'gray',
        tabBarActiveTintColor: 'tomato',
      })}>
      <Tab.Screen name="Badge" component={Badge} />
      <Tab.Screen name="List" component={List} />
      <Tab.Screen name="Post" component={Post} />
      <Tab.Screen name="Delete" component={Delete} />
  </Tab.Navigator>
  );
}


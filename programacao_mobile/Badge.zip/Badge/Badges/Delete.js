import React, { useState, useEffect } from "react";
import { View, Text } from "react-native";

export default function  Delete({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>Delete</Text>
    </View>
  );
}


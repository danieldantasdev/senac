import React, { Component } from "react";
import { Button, View, Text } from "react-native";

export default function Badge() {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>Badge</Text>
    </View>
  );
}
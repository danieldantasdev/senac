import React from "react";
import { Button, View, Text } from "react-native";

const Badge: React.FC = () => {
return (
<View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
<Text>Badge</Text>
</View>
);
}

export default Badge;
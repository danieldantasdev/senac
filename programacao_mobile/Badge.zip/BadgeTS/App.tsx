import * as React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Tabs from './Settings/Tabs';

const Tab = createBottomTabNavigator();

const App: React.FC = () => {
return (
<Tabs/>
);
};

export default App;
package com.example.tela;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button)findViewById(R.id.button);

        button.setOnClickListener( v->{
            EditText origem = (EditText) findViewById(R.id.origem);
            String infoOrigem = origem.getText().toString();

            Intent intent = new Intent(this, Tela2.class);
            intent.putExtra("info", infoOrigem);
            startActivity(intent);
            finish();
        });
    }
}
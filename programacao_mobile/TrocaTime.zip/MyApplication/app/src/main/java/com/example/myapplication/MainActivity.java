package com.example.myapplication;

import static com.example.myapplication.R.drawable.vasco;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private boolean time = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(v->{

            Drawable drawable;
            ImageView imagem = (ImageView) findViewById(R.id.imageView);
            drawable = getDrawable((time=!time)?R.drawable.flamengo:vasco);
            imagem.setImageDrawable(drawable);
        });
    }



}
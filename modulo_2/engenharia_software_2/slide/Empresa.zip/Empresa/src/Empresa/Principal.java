package Empresa;

import controller.EmpresaController;

public class Principal {

	public static void main(String[] args) {
		EmpresaController empresa = new EmpresaController();		
		empresa.iniciarCadastro();
	
	}

}

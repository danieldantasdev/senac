--1 Listar o nome do medico, o andar e n�mero de ambulat�rio onde 
--  presta atendimento, ordenado por andar
SELECT m.nome as medico, a.andar, m.nroa
FROM Medicos m, Ambulatorio a
Where m.nroa=a.nroa
-- Usando JOIN
SELECT m.nome as medico, a.andar, m.nroa
FROM Medicos m JOIN Ambulatorio a ON m.nroa=a.nroa

--2 Buscar o nome dos pacientes que t�m consulta marcada, com a 
--  respectiva data e hora, ordenado por data/hora
SELECT p.nome as paciente, c.data, c.hora
FROM Pacientes p, Consultas c 
Where c.codp=p.codp
Order by c.data, c.hora
-- Usando JOIN
SELECT p.nome as paciente, c.data, c.hora
FROM Pacientes p JOIN Consultas c ON c.codp=p.codp
Order by c.data, c.hora

--3 Buscar o nome do m�dico, o nome do paciente e a data&hora da consulta 
--  ordenado por data/hora
SELECT p.nome as Paciente, m.nome as Medico, c.data, c.hora
FROM Pacientes p, Consultas c, Medicos m
Where c.codp=p.codp and c.codm=m.codm 
Order by c.data, c.hora
-- JOIN
SELECT p.nome as Paciente, m.nome as Medico, c.data, c.hora
FROM (Pacientes p JOIN Consultas c ON c.codp=p.codp ) JOIN Medicos m ON c.codm=m.codm 
Order by c.data, c.hora

--4 Buscar, para as consultas marcadas para o per�odo da manh� (7hs-12hs) do 
--  dia 07/10/2015, o nome do m�dico, o nome do paciente e a data&hora da consulta
SELECT p.nome as Paciente, m.nome as Medico, c.data, c.hora
FROM Pacientes p, Consultas c, Medicos m
Where c.codp=p.codp and c.codm=m.codm AND
      c.data='07/10/2015' and c.hora<='12:00'
-- JOIN
SELECT p.nome as Paciente, m.nome as Medico, c.data, c.hora
FROM (Pacientes p JOIN Consultas c ON c.codp=p.codp ) JOIN Medicos m ON c.codm=m.codm 
WHERE   c.data='07/10/2015' and c.hora<='12:00'

--5 Buscar, para as consultas marcadas para o per�odo da manh� (7hs-12hs) do 
--  dia 07/10/2015, o nome do m�dico, o nome do paciente e a data&hora da consulta e 
--  o ambulat�rio e respectivo andar onde ser� realizada a consulta
SELECT p.nome as Paciente, m.nome as Medico, c.data, c.hora, a.nroa as ambulatorio, a.andar
FROM Pacientes p, Consultas c, Medicos m, Ambulatorio a
Where c.codp=p.codp and c.codm=m.codm AND a.nroa=m.nroa AND
      c.data='07/10/2015' and c.hora<='12:00'
-- JOIN
SELECT p.nome as Paciente, m.nome as Medico, c.data, c.hora
FROM (Pacientes p JOIN Consultas c ON c.codp=p.codp ) JOIN Medicos m ON c.codm=m.codm 
     JOIN Ambulatorio a ON a.nroa=m.nroa
WHERE   c.data='07/10/2015' and c.hora<='12:00'

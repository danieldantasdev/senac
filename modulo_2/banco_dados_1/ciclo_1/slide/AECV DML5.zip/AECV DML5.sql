------ OUTER JOIN ---------------------------
--1 Listar TODOS os m�dicos e suas respectivas consultas, 
--incluindo medicos SEM consulta marcada
SELECT m.nome as medico, c.data, c.hora
FROM Medicos m LEFT OUTER JOIN Consultas c ON c.codm=m.codm

--2 Listar TODOS os Pacientes e suas respectivas consultas, 
--incluindo pacientes SEM consulta marcada
SELECT p.nome as paciente, c.data, c.hora
FROM Pacientes p LEFT OUTER JOIN Consultas c ON c.codp=p.codp

--3 Listar TODOS os m�dicos e TODOS os pacientes e suas respectivas consultas, 
--incluindo pacientes e medicos SEM consulta marcada
SELECT p.nome as paciente, m.nome as medico, c.data, c.hora
FROM (Pacientes p FULL OUTER JOIN Consultas c 
      ON c.codp=p.codp ) FULL OUTER JOIN Medicos m ON c.codm=m.codm 
--4 Listar TODOS os m�dicos e os ambulat�rios onde atendem, 
--  inclusive aqueles que n�o tem ambulat�rio associado 
SELECT m.nome as medico, a.andar, a. nroa
FROM Medicos m LEFT OUTER JOIN Ambulatorio a ON m.nroa=a.nroa

-- 5 Listar Todos os ambulat�rios, inclusive aqueles vazios, isto �, 
--  que n�o tem m�dicos associados 
SELECT m.nome as medico, a.andar, a. nroa
FROM Medicos m RIGHT OUTER JOIN Ambulatorio a ON m.nroa=a.nroa


use HOSPITAL
--1 Quais m�dicos tem a mesma especialidade do medico Daniel?
SELECT nome, especialidade
FROM Medicos
Where especialidade = (SELECT especialidade FROM Medicos 
						WHERE nome='Daniel')

--2 Qual o nome do Ortopedista mais novo?
select nome, idade from medicos 
where idade = (select min(idade) from medicos 
               where especialidade = 'Ortopedia') and
			   especialidade = 'Ortopedia'

--3 Quantos cardiologistas existem no hospital?
select Count(*) as NumCardiologistas
from medicos 
Where especialidade = 'Cardiologia'

--4 Qual a capacidade de leitos do 5� andar?
Select sum(capacidade) as total5Andar from Ambulatorio
where andar = 5

--5 Quais ambulat�rios n�o tem m�dicos alocados?
select nroa, andar, capacidade from Ambulatorio
where nroa not in (select distinct nroa from Medicos where nroa is not NULL)
outras respostas
SELECT * FROM Ambulatorio a
WHERE NOT EXISTS (SELECT * FROM MEDICOS M 
                  WHERE a.nroa=m.nroa)

SELECT * FROM Ambulatorio
WHERE nroa NOT in (SELECT a.nroa FROM Ambulatorio a, medicos m 
                  WHERE m.nroa =a.nroa)


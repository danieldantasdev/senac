use HOSPITAL
----------------------------------------------------------------------------------------
--1 Quantos pacientes existem por doen�a?
SELECT Doen�a, COUNT(*) as QTD
FROM Pacientes
GROUP BY doen�a

--2 Listar m�dicos e especialidades em ordem crescente de especialidade;
SELECT nome, especialidade
FROM medicos
ORDER BY especialidade 

--3 Listar Pacientes e sua doen�a em ordem crescente de doen�a
SELECT nome, doen�a
FROm Pacientes
ORDER BY doen�a

--4 Listar quantidade de m�dicos por Especialidade
SELECT especialidade, count(*) as totalmedicos
FROM Medicos
GROUP BY especialidade

--5 Quais especialidades tem mais de um m�dico?
SELECT especialidade, count(*) as totalmedicos
FROM Medicos
GROUP BY especialidade
HAVING (Count(*)>1)


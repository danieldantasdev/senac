
public class TesteWhile1 {

	public static void main(String[] args) {
		int a=1;
		while (a <= 3) {
			System.out.println("a = " + a);
			a++;
		}
		System.out.println("Valor final de a = " + a);
	}

}

/**
 * 
 * @author reinaldo.freitas
 *
 */
public class HelloWorld {
	public static void main(String[] args) {
		// Imprime uma linha
		System.out.println("Hello World"); // Imprime linha
		System.out.println("-----------"); 
	}
}

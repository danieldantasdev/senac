
public class TesteIfElseifElse1 {

	public static void main(String[] args) {
		int a = 9;
		System.out.println("a = " + a);
		if (a>=10) {
			System.out.println("a � maior ou igual a 10");
		} else if (a>=8) {
			System.out.println("a � maior ou igual a 8");
		} else if (a >= 5) {
			System.out.println("a � maior ou igual a 5");
		} else {
			System.out.println("a � menor do que 5");
		}
	}

}

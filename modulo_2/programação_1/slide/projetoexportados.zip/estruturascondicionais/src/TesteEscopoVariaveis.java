
public class TesteEscopoVariaveis {

	public static void main(String[] args) {
		int a = 1;
		int b=1;
		if (a == 1) {
			b++;
		}
		System.out.println("b = " + b);
	}

}

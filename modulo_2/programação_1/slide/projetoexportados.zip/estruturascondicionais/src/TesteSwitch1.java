
public class TesteSwitch1 {

	public static void main(String[] args) {
		int numero = 1;
		switch (numero) {
		case 1:
			System.out.println("vari�vel numero igual a 1");
			break;
		case 2:
			System.out.println("vari�vel numero igual a 2");
			break;
		default:
			System.out.println("vari�vel numero � diferente de 1 e 2");
			break;
		}
	}

}

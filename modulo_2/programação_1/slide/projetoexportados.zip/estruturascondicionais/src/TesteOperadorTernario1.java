
public class TesteOperadorTernario1 {

	public static void main(String[] args) {
		int idade = 16;
		System.out.println("idade = " + idade);
		System.out.println(idade>=18 ? "adulto" : "n�o � adulto");
		boolean votante;
		votante = (idade >= 16) ? true : false;
		System.out.println(votante ? "Pode votar" : "N�o pode votar");
	}
}


public class TesteOperadoresIncrementoDecremento1 {

	public static void main(String[] args) {
		System.out.println("Pr�-fixado");
		int x = 5;
		System.out.println("x = " + x);
		System.out.println("++x = " + ++x);
		System.out.println("x = " + x);
		System.out.println("--x = " + --x);
		System.out.println("x = " + x);
		System.out.println("P�s-fixado");
		System.out.println("x++ = " + x++);
		System.out.println("x = " + x);
		System.out.println("x-- = " + x--);
		System.out.println("x = " + x);
	}
}

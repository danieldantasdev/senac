package br.senac.rj.teste;

public class TesteMath1{

	public static void main(String[] args) {
		System.out.println("O m�dulo de -3 � = " + Math.abs(-3));
		System.out.println("2 elevado ao cubo = " + Math.pow(2,3));
		System.out.println("Raiz quadrada de 25 = " + Math.sqrt(25));
		System.out.println("3.2 arredondado para cima = " + Math.ceil(3.2));
		System.out.println("3.7 arredondado para baixo = " + Math.floor(3.7));
		System.out.println("Gera um n�mero aleat�rio entre 0 e 1 = " + Math.random());
		System.out.println("Calcula o valor m�nimo entre 1 e 10 = " + Math.min(1, 10));
		System.out.println("Calcula o valor m�ximo entre 1 e 10 = " + Math.max(1, 10));
	}
}

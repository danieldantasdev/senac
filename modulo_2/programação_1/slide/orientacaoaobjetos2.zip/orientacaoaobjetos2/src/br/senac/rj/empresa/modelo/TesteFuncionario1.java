package br.senac.rj.empresa.modelo;

import java.util.Scanner;

public class TesteFuncionario1 {

	public static void main(String[] args) {
		Funcionario func1 = new Funcionario();
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Entre com o registro do funcion�rio: ");
		int registro = Integer.parseInt(sc.nextLine());
		func1.setRegistro(registro);

		System.out.print("Entre com nome do funcion�rio: ");
		String nome = sc.nextLine();
		func1.setNome(nome);

		System.out.print("Entre com o cargo do funcion�rio: ");
		int cargo = Integer.parseInt(sc.nextLine());
		func1.setCargo(cargo);

		System.out.print("Entre com o sal�rio do funcion�rio: ");
		double salario = Double.parseDouble(sc.nextLine());
		func1.setSalario(salario);

		System.out.println("Sal�rio = " + func1.getSalario());
		func1.aplicarBonificacao();
		System.out.println("O novo sal�rio de " + nome + " � " + func1.getSalario());
	}
}

package br.senac.rj.empresa.modelo;


import br.senac.rj.empresa.modelo.Funcionario;

public class Analista extends Funcionario {

}

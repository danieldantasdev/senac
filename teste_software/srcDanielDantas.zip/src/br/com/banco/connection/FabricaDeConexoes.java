package br.com.banco.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaDeConexoes {
	public static Connection getConnection() throws SQLException {
		String url = "jdbc:mysql://localhost/dbagenda?useTimezone=true&serverTimezone=America/Sao_Paulo&useSSL=false";
		String user = "root";
		String password = "010394";
			
		return DriverManager.getConnection(url, user, password);
	}
}

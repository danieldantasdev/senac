package br.com.banco.connection;

import java.sql.Connection;
import java.sql.SQLException;

public class jdbcTesteFabrica {
	public static void main(String[] args) throws SQLException {

		 Connection con = null;
		
		try {
			con = FabricaDeConexoes.getConnection();
			System.out.println("Ok, conectado ao BD");
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.close();
		}
	}
}
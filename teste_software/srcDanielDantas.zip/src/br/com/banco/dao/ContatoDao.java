package br.com.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.banco.connection.FabricaDeConexoes;
import br.com.banco.dao.exception.ExceptionDao;
import br.com.banco.model.Contato;

public class ContatoDao {
	private Connection con;

	public ContatoDao() throws SQLException // se não tem main é throws
	{
		this.con = FabricaDeConexoes.getConnection();
	}

	public void adicionarContato(Contato contato) throws SQLException {
		String sql_insert = "INSERT INTO contatos (nome, email, endereco) VALUES (?, ?, ?)";

		PreparedStatement stmt = con.prepareStatement(sql_insert);
		stmt.setString(1, contato.getNome());
		stmt.setString(2, contato.getEmail());
		stmt.setString(3, contato.getEndereco());

		stmt.execute();
		stmt.close();

	}

	public List<Contato> getContatos() throws SQLException {
		String sql_select = "SELECT * FROM contatos";
		try {
			// faz transações e consultas
			PreparedStatement stmt = con.prepareStatement(sql_select);

			// traz o bloco de tabela do banco
			ResultSet rset = stmt.executeQuery();
			List<Contato> contatos = new ArrayList<Contato>();

			// executa linha a linha no banco, cursor do banco
			while (rset.next()) {
				Contato contato = new Contato();
				contato.setId(rset.getLong("id"));
				contato.setNome(rset.getString("nome"));
				contato.setEndereco(rset.getString("endereco"));
				contato.setEmail(rset.getString("email"));
				contatos.add(contato);
			}

			rset.close();
			stmt.close();

			return contatos;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Contato> getContatosLetra(String letra) throws SQLException {
		String sql_select = "SELECT * FROM contatos WHERE nome LIKE '" + letra + "%'";

		try {
			// faz transações e consultas
			PreparedStatement stmt = con.prepareStatement(sql_select);

			// traz o bloco de tabela do banco
			ResultSet rset = stmt.executeQuery();
			List<Contato> contatos = new ArrayList<Contato>();

			// executa linha a linha no banco, cursor do banco
			while (rset.next()) {
				Contato contato = new Contato();
				contato.setId(rset.getLong("id"));
				contato.setNome(rset.getString("nome"));
				contato.setEndereco(rset.getString("endereco"));
				contato.setEmail(rset.getString("email"));
				contatos.add(contato);
			}

			rset.close();
			stmt.close();

			return contatos;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public List<Contato> pesquisarContato(Long id){
		String sql = "Select * from contatos where id="+id;
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			List<Contato> contatos = new ArrayList<Contato>();
			while(rs.next()){
				Contato contato = new Contato();
				contato.setId(rs.getLong("id"));
				contato.setNome(rs.getString("nome"));
				contato.setEndereco(rs.getString("endereco"));
				contato.setEmail(rs.getString("email"));
				
				
				contatos.add(contato);
			}
			
			rs.close();
			stmt.close();
			
			return contatos;
			
		} catch (Exception e) {
			throw new ExceptionDao(e);
		}
	}

	public void alterarContato(Contato contato) {
		String sql_update = "update contatos set nome=?, email=?, endereco=? where id=?";
		try {
			PreparedStatement stmt = con.prepareStatement(sql_update);
			stmt.setString(1, contato.getNome());
			stmt.setString(2, contato.getEmail());
			stmt.setString(3, contato.getEndereco());
			stmt.setLong(4, contato.getId());
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void removerContato(Contato contato) {
		try {
			PreparedStatement stmt = con.prepareStatement("DELETE FROM contatos where id=?");
			stmt.setLong(1, contato.getId());
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}

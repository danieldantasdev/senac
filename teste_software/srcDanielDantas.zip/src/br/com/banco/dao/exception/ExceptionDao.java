package br.com.banco.dao.exception;

@SuppressWarnings("serial")
public class ExceptionDao extends RuntimeException {

	public ExceptionDao() {
			super("Causa do erro desconhecida");
		}

	public ExceptionDao(String message) {
			super(message);
		}

	public ExceptionDao(Throwable cause) {
			super(cause);
		}

	public ExceptionDao(String message, Throwable cause) {
			super(message, cause);
		}

}

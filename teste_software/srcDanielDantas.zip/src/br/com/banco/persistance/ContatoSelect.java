package br.com.banco.persistance;

import java.sql.SQLException;
import java.util.List;

import br.com.banco.dao.ContatoDao;
import br.com.banco.model.Contato;

public class ContatoSelect {
	public static void main(String[] args) {
		try {
			ContatoDao cdao = new ContatoDao();
			List <Contato> contatos = cdao.getContatos();
			
			for (Contato contato : contatos) {
				System.out.println("=============================================");
				System.out.println("Id: " + contato.getId() + "\n");
				System.out.println("Nome: " + contato.getNome() + "\n");
				System.out.println("Email: " + contato.getEmail() + "\n");
				System.out.println("Endereço: " + contato.getEndereco() + "\n");
				System.out.println("=============================================");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

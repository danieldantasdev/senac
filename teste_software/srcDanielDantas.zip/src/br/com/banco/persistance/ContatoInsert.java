package br.com.banco.persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.banco.connection.FabricaDeConexoes;

public class ContatoInsert {
	public static void main(String[] args) {
		try {
			Connection con = FabricaDeConexoes.getConnection();
			String sql_insert = "INSERT INTO contatos (nome, email, endereco) VALUES (?, ?, ?)";
			PreparedStatement stmt = con.prepareStatement(sql_insert);
			//fluxo de transão, está em memória ainda
			stmt.setString(1, "Daniel Dantas");
			stmt.setString(2, "contatodaniel@gmail.com");
			stmt.setString(3, "Caxias, 10.000");
			//vai ao br.com.banco.connection
			stmt.execute();
			
			if(stmt.execute()) {				
				System.out.println("Gravação efetuada com sucesso!");
			}else {
				System.out.println("Não foi possível salvar!!");
			}
			
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

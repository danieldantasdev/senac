package br.com.banco.view;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import br.com.banco.dao.ContatoDao;
import br.com.banco.model.Contato;

public class Main {

	public static void main(String[] args) throws SQLException {

		Scanner sc = new Scanner(System.in);
		Contato contato = new Contato();
		ContatoDao contatoDao = new ContatoDao();
		int opcao;

		do {
			System.out.print("##--Gerenciamento de contatos--##\n\n");
			System.out.print("|-----------------------------|\n");
			System.out.println("1 - Inserir contato");
			System.out.println("2 - Listar contatos");
			System.out.println("3 - Listar contatos por uma letra");
			System.out.println("4 - Pesquisar contato");
			System.out.println("5 - Atualizar contato");
			System.out.println("6 - Deletar contato");
			System.out.println("7 - Encerrar");
			System.out.print("|-----------------------------|\n");
			System.out.print("Digite uma opção: ");

			opcao = Integer.parseInt(sc.nextLine());
			
			if (opcao < 1 || opcao > 7) {
				System.out.println("Opção incorreta!");
			} else if(opcao == 0){
				System.out.println("Opção incorreta!");
			}else {
				if (opcao != 7) {
					try {
						switch (opcao) {
						case 1:
							System.out.print("Entre com o nome = ");
							contato.setNome(sc.nextLine());

							System.out.print("Entre com o email = ");
							contato.setEmail(sc.nextLine());

							System.out.print("Entre com o endereco = ");
							contato.setEndereco(sc.nextLine());

							contatoDao.adicionarContato(contato);
							break;
						case 2:
							List<Contato> contatos = contatoDao.getContatos();
							SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");

							for (Contato contatoList : contatos) {
								System.out.println("-------------------------------");
								System.out.println("Nome: " + contatoList.getNome());
								System.out.println("Email: " + contatoList.getEmail());
								System.out.println("Endereço: " + contatoList.getEndereco());
								System.out.println("-------------------------------");
							}

							break;
						case 3:
							System.out.println("Insira a letra para pesquisar: ");
							String s = sc.nextLine();

							List<Contato> contatosLetra = contatoDao.getContatosLetra(s);

							for (Contato contatoList : contatosLetra) {
								System.out.println("-------------------------------");
								System.out.println("Nome: " + contatoList.getNome());
								System.out.println("Email: " + contatoList.getEmail());
								System.out.println("Endereço: " + contatoList.getEndereco());
								System.out.println("-------------------------------");
							}
							break;
						case 4:
							System.out.print("Entre com o id = ");
							Long id = contato.setId(Long.parseLong(sc.nextLine()));

							List<Contato> lista = contatoDao.pesquisarContato(id);
							for (Contato contatosPesquisa : lista) {
								System.out.println("-------------------------------");
								System.out.println("Id:" + contatosPesquisa.getId());
								System.out.println("Nome:" + contatosPesquisa.getNome());
								System.out.println("Email:" + contatosPesquisa.getEmail());
								System.out.println("Endereco:" + contatosPesquisa.getEndereco());
								System.out.println("-------------------------------");
							}
							break;
						case 5:
							System.out.print("Entre com o id = ");
							contato.setId(Long.parseLong(sc.nextLine()));

							System.out.print("Entre com o nome = ");
							contato.setNome(sc.nextLine());

							System.out.print("Entre com o email = ");
							contato.setEmail(sc.nextLine());

							System.out.print("Entre com o endereco = ");
							contato.setEndereco(sc.nextLine());

							contatoDao.alterarContato(contato);
							break;
						case 6:
							System.out.print("Entre com o id = ");
							contato.setId(Long.parseLong(sc.nextLine()));
							try {
								contatoDao.removerContato(contato);
							} finally {
								System.out.println("Apagado com sucesso!!");
							}
							break;
						case 7:
							System.out.println("Programa encerrado!");
							sc.close();
							System.exit(0);
							break;
						}
					} catch (NumberFormatException erro) {
						System.out.println("Entre com o formato correto dos dados!");
					} catch (Exception erro) {
						System.out.println("Erro não identificado: " + erro.toString());
					}
				}
			}
		} while (opcao != 0);
		System.out.println("Programa encerrado!");
		sc.close();
		System.exit(0);
	}
}

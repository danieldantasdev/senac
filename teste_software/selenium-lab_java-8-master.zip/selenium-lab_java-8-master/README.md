# selenium-lab
selenium-lab

# OBS:
caso os testes da classe [ProductTest](./src/test/java/sistemadetestes/test/ProductTest.java) forem executados individualmente, favor, descomentar as linhas 71 e 82
package banco;

import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import dao.ContatoDAO;
import modelo.Contato;



public class Menu {
	
	public void listarAtributos(Contato contato) {
		System.out.println("Nome: "+ contato.getNome());
		System.out.println("Email: "+ contato.getEmail());
		System.out.println("Endereco: "+ contato.getEndereco());
		System.out.println("---------------------------\n");
	}
	
	public static void main(String[] args) {
		System.out.println("Bem vindo a Meus Contatos!");
		System.out.println("Para come�ar, escolha uma opcao");
		String menu;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1- Inserir um novo contato.");
			System.out.println("2- Listar todos os contatos.");
			System.out.println("3- Filtrar lista por inicial do nome.");
			System.out.println("4- Buscar um contato.");
			System.out.println("5- Editar um contato.");
			System.out.println("6- Excluir um contato");
			System.out.println("S- Sair");
			menu = sc.next().toLowerCase();
			menu = menu.toLowerCase();
			switch(menu) {
				//Inserir contato
				case "1":{
					Contato contato = new Contato();
					System.out.println("Insira o nome: ");
					contato.setNome(sc.next());
					System.out.println("Insira o email: ");
					contato.setEmail(sc.next());
					System.out.println("Insira o endereco");
					contato.setEndereco(sc.next());
					try {
						ContatoDAO cDao = new ContatoDAO();
						cDao.adicionarContato(contato);
						System.out.println("Contato salvo com sucesso!\n");
						cDao.fecharConexao();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					break;
				}
				
				//listar contatos
				case "2":{
					ContatoDAO cDao;
					try {
						cDao = new ContatoDAO();
						List<Contato> contatos = cDao.getContatos();
						for (Contato contato : contatos) {
							System.out.println("Id: "+ contato.getId());
							System.out.println("Nome: "+ contato.getNome());
							System.out.println("Email: "+ contato.getEmail());
							System.out.println("Endereco: "+ contato.getEndereco());
							System.out.println("---------------------------\n");
						}
						cDao.fecharConexao();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					System.out.println("Aperte enter para continuar.");
					InputStreamReader espera;
					try {
					       espera = new InputStreamReader(System.in);
					       espera.read();
					} catch (IOException e) {
					       e.printStackTrace();
					}
					break;
				}
				
				//listar contatos pela inicial
				case "3":{
					ContatoDAO cDao;
					try {
						cDao = new ContatoDAO();
						System.out.println("Informe a inicial do nome: ");
						String letra = sc.next();
						List<Contato> contatos = cDao.getContatoByFirstChar(letra);
						for (Contato contato : contatos) {
							System.out.println("Id: "+ contato.getId());
							System.out.println("Nome: "+ contato.getNome());
							System.out.println("Email: "+ contato.getEmail());
							System.out.println("Endereco: "+ contato.getEndereco());
							System.out.println("---------------------------\n");
						}
						cDao.fecharConexao();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					System.out.println("Aperte enter para continuar.");
					InputStreamReader espera;
					try {
					       espera = new InputStreamReader(System.in);
					       espera.read();
					} catch (IOException e) {
					       e.printStackTrace();
					}
					break;
				}
				
				//buscar contato
				case "4":{
					System.out.println("Informe o ID: ");
					String id = sc.next();
					try {
						ContatoDAO cDao = new ContatoDAO();
						Contato contato = cDao.getContatoById(id);
						if(contato != null) {
							System.out.println("Nome: "+ contato.getNome());
							System.out.println("Email: "+ contato.getEmail());
							System.out.println("Endereco: "+ contato.getEndereco());
							System.out.println("---------------------------\n");
						} else {
							System.out.println("Nenhum contato encotrado");
						}
						cDao.fecharConexao();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					System.out.println("Aperte enter para continuar.");
					InputStreamReader espera;
					try {
					       espera = new InputStreamReader(System.in);
					       espera.read();
					} catch (IOException e) {
					       e.printStackTrace();
					}
					break;
				}
				
				//editar contato
				case "5":{
					System.out.println("Informe o ID: ");
					String id = sc.next();
					try {
						ContatoDAO cDao = new ContatoDAO();
						Contato contato = cDao.getContatoById(id);
						System.out.println("\n");
						if(contato != null) {
							System.out.println("Informacoes do contato:");
							System.out.println("Nome: "+ contato.getNome());
							System.out.println("Email: "+ contato.getEmail());
							System.out.println("Endereco: "+ contato.getEndereco());
							System.out.println("---------------------------\n");
							String opUpdateContinue = null;
							do{
								System.out.println("O que voce deseja alterar?");
								System.out.println("1- Nome.\n2- Email.\n3- Endereco\n");
								String opUpdate = sc.next();
								
								switch(opUpdate) {
									case "1":{
										System.out.println("Insira o novo nome: ");
										contato.setNome(sc.next());
										break;
									}
									
									case "2":{
										System.out.println("Insira o novo email: ");
										contato.setEmail(sc.next());
										break;
									}
									
									case "3":{
										System.out.println("Insira o novo endereco: ");
										contato.setEndereco(sc.next());
										break;
									}
									
									default:{
										System.out.println("Insira uma opcao valida");
										break;
									}
								}
								
								do {
									System.out.println("Deseja continuar editando?\n1- Sim.\n2- Nao.");
									opUpdateContinue = sc.next().toLowerCase();
									switch(opUpdateContinue) {
										
										case "1":{
											System.out.println("Informacoes do contato:");
											System.out.println("Nome: "+ contato.getNome());
											System.out.println("Email: "+ contato.getEmail());
											System.out.println("Endereco: "+ contato.getEndereco());
											System.out.println("---------------------------\n");
											break;
										}
									
										case "2":{
											boolean res = cDao.updateContato(contato);
											if(res) {
												System.out.println("Contato alterado com sucesso.");
											} else {
												System.out.println("Falha na edi��o.");
											}
											break;
										}
										
										default:{
											System.out.println("Informe uma opcao valida");
											break;
										}
									}
								}while(!(opUpdateContinue.equals("1")||opUpdateContinue.equals("2")));
								
							}while(!opUpdateContinue.equals("2"));
							
						} else {
							System.out.println("Nenhum contato encotrado");
						}
						cDao.fecharConexao();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					break;
				}
				
				//excluir
				case "6":{
					System.out.println("Informe o ID: ");
					String id = sc.next();
					ContatoDAO cDao;
					try {
						cDao = new ContatoDAO();
						Contato contato = cDao.getContatoById(id);
						System.out.println("\n");
						if(contato != null) {
							System.out.println("O contato com o "+ id +"id e:");
							System.out.println("Nome: "+ contato.getNome());
							System.out.println("Email: "+ contato.getEmail());
							System.out.println("Endereco: "+ contato.getEndereco());
							System.out.println("---------------------------\n");
							System.out.println("\nDeseja deletar o contato? 1- Sim  2- Nao");
							String opDelete = sc.next();
							if(opDelete.equalsIgnoreCase("1")) {
								boolean res = cDao.deleteContato(contato);
								if(res) {
									System.out.println("Contato deletado com sucesso!");
								} else {
									System.out.println("Falha ao deletar o contato.");
								}
							} else {
								System.out.println("Cancelando operacao...");
							}
						} else {
							System.out.println("Nenhum contato encotrado");
						}
						cDao.fecharConexao();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					break;
				}
				
				case "7":{
					System.out.println("Obrigado por utilizar o aplicativo!");
					break;
				}
				
				default:{
					System.out.println("Insira uma opcao valida");
					break;
				}
			}
		}while(!menu.equals("7"));
		sc.close();
	}
	

}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import banco.FabricaDeConexoes;
import modelo.Contato;

public class ContatoDAO {
	private Connection conexao;
	
	public ContatoDAO() throws SQLException {
		this.conexao = FabricaDeConexoes.getConnection();
	}
	
	public boolean adicionarContato(Contato contato) throws SQLException {
		String create_contato = "INSERT INTO CONTATOS(contato_nome, contato_email, contato_endereco) VALUES (?, ?, ?);";
		PreparedStatement prSt = conexao.prepareStatement(create_contato);
		prSt.setString(1, contato.getNome());
		prSt.setString(2, contato.getEmail());
		prSt.setString(3, contato.getEndereco());
		prSt.execute();
		prSt.close();
		return true;
	}
	
	public List<Contato> getContatos() throws SQLException{
		String select_contato = "SELECT * FROM CONTATOS";
		PreparedStatement prSt = conexao.prepareStatement(select_contato);
		ResultSet rSet = prSt.executeQuery();
		
		List<Contato> contatos = new ArrayList<Contato>();
		while(rSet.next()) {
			Contato contato = new Contato();
			contato.setId(Long.parseLong(rSet.getString("contato_id")));
			contato.setNome(rSet.getString("contato_nome"));
			contato.setEmail(rSet.getString("contato_email"));
			contato.setEndereco(rSet.getString("contato_endereco"));
			
			contatos.add(contato);
		}
		rSet.close();
		prSt.close();
		return contatos;
	}
	
	public Contato getContatoById(String id) throws SQLException {
		String select_id = "Select * from CONTATOS where contato_id = (?)";
		PreparedStatement prSt = conexao.prepareStatement(select_id);
		prSt.setString(1, id);
		ResultSet rSet = prSt.executeQuery();
		if(rSet.next()) {
			Contato contato = new Contato();
			contato.setId(Long.parseLong(rSet.getString("contato_id")));
			contato.setNome(rSet.getString("contato_nome"));
			contato.setEmail(rSet.getString("contato_email"));
			contato.setEndereco(rSet.getString("contato_endereco"));
			return contato;
		}
		rSet.close();
		prSt.close();
		return null;
	}

	public List<Contato> getContatoByFirstChar(String letra) throws SQLException{
		String select_first_char = "SELECT * FROM CONTATOS where contato_nome LIKE ?";
		PreparedStatement prSt = conexao.prepareStatement(select_first_char);
		prSt.setString(1, letra+"%");
		ResultSet rSet = prSt.executeQuery();
		List<Contato> contatos = new ArrayList<Contato>();
		while(rSet.next()) {
			Contato contato = new Contato();
			contato.setId(Long.parseLong(rSet.getString("contato_id")));
			contato.setNome(rSet.getString("contato_nome"));
			contato.setEmail(rSet.getString("contato_email"));
			contato.setEndereco(rSet.getString("contato_endereco"));
			
			contatos.add(contato);
		}
		rSet.close();
		prSt.close();
		return contatos;
	}
	
	public boolean updateContato(Contato contato) throws SQLException {
		String update_contato = "UPDATE Contatos SET contato_nome = ?, contato_email = ?, contato_endereco = ? WHERE contato_id = ?";
		PreparedStatement prSt = conexao.prepareStatement(update_contato);
		prSt.setString(1, contato.getNome());
		prSt.setString(2, contato.getEmail());
		prSt.setString(3, contato.getEndereco());
		prSt.setLong(4, contato.getId());
		boolean res = prSt.execute();
		prSt.close();
		return res;
	}
	
	public boolean deleteContato(Contato contato) throws SQLException {
		String delete_contato = "DELETE FROM Contatos WHERE contato_id = ?";
		PreparedStatement prSt = conexao.prepareStatement(delete_contato);
		prSt.setLong(1, contato.getId());
		boolean res = prSt.execute();
		prSt.close();
		return res;
	}
	
	public boolean fecharConexao() throws SQLException {
		conexao.close();
		return true;
	}
}


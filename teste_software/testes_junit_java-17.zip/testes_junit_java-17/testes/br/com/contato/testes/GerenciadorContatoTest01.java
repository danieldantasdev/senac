package br.com.contato.testes;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.contato.actions.GerenciadoraContato;
import br.com.contato.model.Contato;

/**
 * Classe de teste criada para garantir o funcionamento das principais opera��es
 * sobre contatos, realizadas pela classe {@link GerenciadoraContato}.
 * 
 * @author Daniel Dantas
 * @date 01/05/2023
 */
public class GerenciadorContatoTest01 {

	private GerenciadoraContato gerenciadoraContato;
	private int idContato01 = 1;
	private int idContato02 = 2;

	@Before
	public void setUp() {
		/* ========== Montagem do cen�rio ========== */

		// criando lista vazia de contatos
		List<Contato> contatos = new ArrayList<>();

		// criando e inserindo duas contatos na lista de contatos
		Contato contato01 = new Contato(1, "Daniel", "daniel@gmail.com", "RJ");
		Contato contato02 = new Contato(2, "eve", "eve@gmail.com", "RJ");

		contatos.add(contato01);
		contatos.add(contato02);

		gerenciadoraContato = new GerenciadoraContato(contatos);
	}

	@After
	public void tearDown() {
		// ************* Desmontagem do cenário global **********//
		gerenciadoraContato.limpa();
	}

	/**
	 * @method Adicionar Contato
	 */
	@Test
	public void testAdicionarContato() {
		Contato contato = new Contato(3, "Fulano", "1111-1111", "fulano@teste.com");
		gerenciadoraContato.adicionaContato(contato);
		assertEquals(3, gerenciadoraContato.getContatos().size());
		assertTrue(gerenciadoraContato.getContatos().contains(contato));
	}

	/**
	 * @method Adicionar Contato
	 */
	@Test
	public void testAdicionarContatoIgnoreNull() {
		gerenciadoraContato.adicionaContato(null);
		assertEquals(3, gerenciadoraContato.getContatos().size());
	}

	/**
	 * @method Remover Contato
	 */
	@Test
	public void testRemoverContato() {
		Contato contato = new Contato(3, "Fulano", "1111-1111", "fulano@teste.com");
		gerenciadoraContato.adicionaContato(contato);
		gerenciadoraContato.removeContato(3);
		assertEquals(2, gerenciadoraContato.getContatos().size());
		assertFalse(gerenciadoraContato.getContatos().contains(contato));
	}

	/**
	 * @method Remover Contato
	 */
	@Test
	public void testRemoverContatoIgnoreNull() {
		gerenciadoraContato.removeContato(1);
		assertEquals(1, gerenciadoraContato.getContatos().size());
	}

	/**
	 * Teste b�sico da remo��o de um cliente a partir do seu ID.
	 * 
	 * @author Daniel Dantas
	 * @date 01/05/2023
	 */

	@Test
	public void testRemoveContato() {

		/* ========== Execu��o ========== */
		boolean clienteRemovido = gerenciadoraContato.removeContato(idContato02);

		/* ========== Verifica��es ========== */
		assertThat(clienteRemovido, is(false));
		assertThat(gerenciadoraContato.getContatos().size(), is(1));
		assertNull(gerenciadoraContato.pesquisaContatoPorId(idContato02));
	}

	/**
	 * @method Pesquisar Contato
	 */
	@Test
	public void testPesquisarContatoPorId() {
		Contato contato = new Contato(4, "Fulano", "1111-1111", "fulano@teste.com");
		gerenciadoraContato.adicionaContato(contato);
		assertEquals(contato, gerenciadoraContato.pesquisaContatoPorId(4));
		assertNull(gerenciadoraContato.pesquisaContatoPorId(-1));
	}

	/**
	 * @method Pesquisar Contato
	 */
	@Test
	public void testPesquisarContatoPorIdIgnoreNull() {
		assertNull(gerenciadoraContato.pesquisaContatoPorId(-1));
		assertNull(gerenciadoraContato.pesquisaContatoPorId(-10));
	}

	/**
	 * @method Pesquisar Contato
	 */
	@Test
	public void testPesquisarContatoPorIdNullIdMajorSizeList() {
		assertNull(gerenciadoraContato.pesquisaContatoPorId(0));
		assertNull(gerenciadoraContato.pesquisaContatoPorId(10));
	}

	/**
	 * Teste b�sico da pesquisa de um cliente a partir do seu ID.
	 * 
	 * @author Daniel Dantas
	 * @date 01/05/2023
	 */
	@Test
	public void testPesquisaContato() {
		/* ========== Execu��o ========== */
		Contato contato = gerenciadoraContato.pesquisaContatoPorId(idContato01);

		/* ========== Verifica��es ========== */
		assertThat(contato.getId(), is(idContato01));
	}
}

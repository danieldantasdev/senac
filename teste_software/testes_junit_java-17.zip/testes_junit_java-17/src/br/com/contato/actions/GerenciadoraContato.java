package br.com.contato.actions;

import java.util.List;

import br.com.contato.model.Contato;


/**
 * 
 * @author Daniel Dantas
 *
 */
public class GerenciadoraContato {
	private List<Contato> contatos;

	public GerenciadoraContato(List<Contato> contatos) {
		this.contatos = contatos;
	}

	/**
	 * Retorna uma lista com todas os contatos.
	 * @return lista com todas os contatos
	 */
	public List<Contato> getContatos() {
		return contatos;
	}

	/**
	 * Pesquisa por uma conta a partir do seu ID.
	 * @param idConta id da conta a ser pesquisada
	 * @return a conta pesquisada ou null, caso n�o seja encontrada
	 */
	public Contato pesquisaContatoPorId (int idConta) {

		for (Contato contaCorrente : contatos) {
			if(contaCorrente.getId() == idConta)
				return contaCorrente;
		}
		return null;
	}
	
	/**
	 * Adiciona uma nova conta � lista os contatos.
	 * @param novaConta nova conta a ser adicionada
	 */
	public void adicionaContato (Contato novaConta) {
		this.contatos.add(novaConta);
	}

	/**
	 * Remove conta da lista os contatos.
	 * @param idConta ID da conta a ser removida 
	 * @return true se a conta foi removida. False, caso contr�rio.
	 */
	public boolean removeContato (int idConta) {
		
		boolean contaRemovida = false;
		
		for (int i = 0; i < contatos.size(); i++) {
			Contato conta = contatos.get(i);
			if(conta.getId() == idConta){
				contatos.remove(i);
				break;
			}
		}
		
		return contaRemovida;
	}
	
	public void limpa() {
		contatos.clear();
	}

	
}

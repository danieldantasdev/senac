package br.com.contato;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import br.com.contato.actions.GerenciadoraContato;
import br.com.contato.model.Contato;

public class Main {

	static GerenciadoraContato gerenciadoraContato;

	public static void main(String[] args) {

		inicializaSistemaBancario(); // criando algumas contas e gerenciadoraContatos fict�cios

		Scanner sc = new Scanner(System.in);
		boolean continua = true;

		while (continua) {

			printMenu();

			int opcao = sc.nextInt();

			switch (opcao) {
			// Consultar por um gerenciadoraContato
			case 1:
				System.out.print("Digite o ID do gerenciadoraContato: ");
				int idCliente = sc.nextInt();
				Contato contato = gerenciadoraContato.pesquisaContatoPorId(idCliente);

				if (contato != null)
					System.out.println(contato.toString());
				else
					System.out.println("Cliente n�o encontrado!");

				pulalinha();
				break;

			// Sair
			case 2:
				continua = false;
				System.out.println("################# Sistema encerrado #################");
				break;

			default:
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println();
				break;

			}

		}

	}

	private static void pulalinha() {
		System.out.println("\n");
	}

	/**
	 * Imprime menu de op��es do nosso sistema banc�rio
	 */
	private static void printMenu() {

		System.out.println("O que voc� deseja fazer? \n");
		System.out.println("1) Consultar por um gerenciadoraContato");
		System.out.println("2) Sair");
		System.out.println();

	}

	/**
	 * M�todo que cria e insere algumas contas e gerenciadoraContatos no sistema do
	 * banco, apenas para realiza��o de testes manuais atrav�s do m�todo main acima.
	 */
	private static void inicializaSistemaBancario() {
		// criando lista vazia de contas e clientes
		List<Contato> contatos = new ArrayList<>();

		// criando e inserindo duas contas na lista de contas correntes do banco
		Contato contato01 = new Contato(1, "Daniel", "daniel@gmail.com", "RJ");
		Contato contato02 = new Contato(2, "eve", "eve@gmail.com", "RJ");

		contatos.add(contato01);
		contatos.add(contato02);

		gerenciadoraContato = new GerenciadoraContato(contatos);
	}

}
